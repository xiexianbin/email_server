package com.stopthread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Iterator;
import java.util.Set;

public class ManageThread implements Runnable {

	private Socket clientSocket;
	private PrintStream ps;
	private BufferedReader br;
	public ManageThread(Socket clientSocket){
		this.clientSocket = clientSocket;
		try {
			this.ps = new PrintStream(clientSocket.getOutputStream());
			this.br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			ps.println("�˵���1.�鿴����\t2.��������");
			try {
				String menu = br.readLine();
				
				if(menu.equals("1")){
					if(ThreadMap.threadMap.size()==0){
						ps.println("û��Ҫ�رյĽ��̡�");
					}else{
						Set<String> keySet = ThreadMap.threadMap.keySet();
						Iterator<String> it = keySet.iterator();
						while(it.hasNext()){
							String key = it.next();
							ps.println(key);
						}
					}
					
				}else if(menu.equals("2")){
					while(true){
						ps.println("������Ҫ�رյ��̣߳�");
						String threadName = br.readLine();
						if(ThreadMap.threadMap.containsKey(threadName)){
							Thread th = ThreadMap.threadMap.get(threadName);
							
						}else{
							ps.println("�������");
							break;
						}
					}
				}else{
					continue;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
			
		}
	}

}
