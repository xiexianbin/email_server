package com.stopthread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class ThreadCreateOne implements Runnable {

	private Socket client;
	private PrintStream ps;
	private BufferedReader br;
	private boolean flag = true;
	//������
	public ThreadCreateOne(Socket client){
		this.client = client;
		try {
			this.ps = new PrintStream(client.getOutputStream());
			this.br = new BufferedReader(new InputStreamReader(client.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void stopThread(){
		this.flag = false;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			try {
				while(flag){
					Thread.sleep(1000);
					System.out.println("thread one.");
					
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
