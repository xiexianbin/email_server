package com.stopthread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ManaServer implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//ͨ��telnet 8888�˿ڹ����̡߳�
		try {
			ServerSocket threadServer = new ServerSocket(8888);
			System.err.println("8888���̹�����������");
			while(true){
				Socket clientSocket = threadServer.accept();
				ManageThread manage = new ManageThread(clientSocket);
				Thread thManage = new Thread(manage);
				thManage.start();
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
