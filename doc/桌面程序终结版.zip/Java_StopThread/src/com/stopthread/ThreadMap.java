package com.stopthread;

import java.util.HashMap;
import java.util.Map;

public class ThreadMap {

	public static Map<String, Thread> threadMap = new HashMap<String, Thread>();
	
}
