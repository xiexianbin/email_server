package com.stopthread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class CreateServer implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//ͨ��telnet 4545�˿������µ��̡߳�
		int i=0;
		try {
			ServerSocket server = new ServerSocket(4545);
			System.err.println("4545����������������");
			while(true){
				Socket client = server.accept();
				ThreadCreateOne threadOne = new ThreadCreateOne(client);
				Thread th1 = new Thread(threadOne);
				th1.start();
				ThreadMap.threadMap.put("t"+(i++), th1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
